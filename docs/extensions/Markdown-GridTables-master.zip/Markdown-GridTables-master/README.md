Markdown-GridTables
===================

Smart grid tables will convert ascii grid tables to proper html grid tables.